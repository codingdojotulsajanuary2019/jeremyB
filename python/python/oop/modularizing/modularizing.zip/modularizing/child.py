import parent

print(locals())