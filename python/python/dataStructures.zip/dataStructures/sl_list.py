from sl_node import Node

class SList:
    def __init__(self):
        self.head = None
    
    def add_to_front(self, val):
        new_node = Node(val)
        new_node.next = self.head
        self.head = new_node
        return self
    
    def print_values(self):
        runner = self.head
        while (runner != None):
            print(runner.value)
            runner = runner.next
        return self

    def add_to_back(self, val):
        if self.head == None:
            self.add_to_front(val)
            return self

        new_node = Node(val)
        runner = self.head
        while (runner.next != None):
            runner = runner.next
        runner.next = new_node
        return self

    def remove_from_front(self):
        if self.head == None:
            return self

        self.head = self.head.next
        return self

    def remove_from_back(self):
        if self.head == None:
            return self
        
        
