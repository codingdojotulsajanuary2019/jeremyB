from sl_list import SList
from sl_node import Node

my_list = SList()
# my_list.add_to_front("second").add_to_front("first").add_to_back("third").remove_from_front().print_values()

my_list.remove_from_front()